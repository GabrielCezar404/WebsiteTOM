package wtom.model.service.exception;

public class UsuarioInvalidoException extends Exception {
    public UsuarioInvalidoException(String mensagem) {
        super(mensagem);
    }
}
