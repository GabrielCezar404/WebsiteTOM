package wtom.dao.exception;


public class PersistenciaException extends Exception {
    
    public PersistenciaException(String msg){
        super(msg);
    }
}
