package wtom.autorizacao;

public class ControleAutorizacao {
    
}
